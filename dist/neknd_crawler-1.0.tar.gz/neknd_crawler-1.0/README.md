`markdown
# 中国教育新闻网新闻采集系统

![Python](https://img.shields.io/badge/python-3.8%2B-blue)

## 📌 功能特性
- 定时抓取中国教育新闻网职教板块新闻
- 自动存储标题、链接、发布时间、来源、正文等内容
- 支持防封禁策略（请求间隔、robots.txt检测）
- 数据库去重与时间过滤机制

## 🚀 快速开始

### 环境要求
- Python 3.8+
- MySQL 5.7+

### 安装依赖

- 参考requirements.txt文件